function [NewLabel] = BestMapping(La1,La2)



Label1=unique(La1');
L1=length(Label1);
Label2=unique(La2');
L2=length(Label2);


G = zeros(max(L1,L2),max(L1,L2));
for i=1:L1
    index1= La1==Label1(1,i);
    for j=1:L2
        index2= La2==Label2(1,j);
        G(i,j)=sum(index1.*index2);
    end
end


[index]=munkres(-G);

[temp]=MarkReplace(index);

NewLabel=zeros(size(La2));
for i=1:L2
    NewLabel(La2==Label2(i))=temp(i);
end

end
