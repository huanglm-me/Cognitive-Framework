clc;
clear;
x1=rand(200,100)*10000;  

x2=rand(100,100)*10000;
x3 = x2+randperm(1000,1);
x4 = [x2;x3];
x5 = [x1;x4];
Idx = kmeans(x5,300);

BD1=1:200;
BD2=BD1.';
BD3 = 201:300;
BD4=BD3.';

Y=[BD2;BD4;BD4];

[NewLabel]=BestMapping(Y,Idx);
 

%ACC label_num = 300
acc=Acc(Y,NewLabel);
fprintf('Clustering-Acc��%f\n',acc); 

%NMI label_num = 300
nmi=Nmi(Y',Idx');
fprintf('Clustering-Nmi��%f\n',nmi); 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

BT1=1:200;
BT2=BT1.';

BT3 = 201:250;
BT4=BT3.';

BT5 = 251:300;
BT6=BT5.';

BT7 = 201:250;
BT8=BT7.';

BT9 = 301:350;
BT10=BT9.';

Y2=[BT2;BT4;BT6;BT8;BT10];

[NewLabel2]=BestMapping(Y2,Idx);
 
%ACC label_num = 350
acc2=Acc(Y2,NewLabel2);
fprintf('Clustering-Acc2��%f\n',acc2); 

%NMI label_num = 350
nmi2=Nmi(Y2',Idx');
fprintf('Clustering-Nmi2��%f\n',nmi2); 