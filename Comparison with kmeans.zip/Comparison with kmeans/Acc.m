function acc = Acc(Label1,Label2)


T= Label1==Label2;
acc=sum(T)/length(Label2);

end
